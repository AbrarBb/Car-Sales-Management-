package project;

interface Person {

    public String getName();

    public void setName(String name);

    public String getAddress();

    public void setAddress(String address);

    public String getEmail();

    public void setEmail(String email);

    public String getPhone();

    public void setPhone(String phone);

    public String toString();
}
